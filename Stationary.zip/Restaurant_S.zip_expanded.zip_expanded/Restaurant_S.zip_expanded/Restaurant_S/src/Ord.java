import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.ConnectException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.*;



import javax.swing.JButton;
import javax.swing.JTextField;

public class Ord extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Ord frame = new Ord();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Ord() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		String[] n = {"Compass","File","Books","Pen","Pencil","Eraser","TextBook","Novel","GeometryBox"};
		JComboBox comboBox = new JComboBox(n);
		comboBox.setBounds(55,96, 128, 20);
		contentPane.add(comboBox);
		comboBox.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				String s = (String) comboBox.getSelectedItem();
				switch (s) {
				case "Compass":
					textField.setText("Compass");
					textField_1.setText("60");
					break;
					
				case "File":
					textField.setText("File");
					textField_1.setText("10");
					
					break;

				default:
					break;
				}
				
			}
		});

		
		JLabel lblMenu = new JLabel("Menu");
		lblMenu.setFont(new Font("Adobe Caslon Pro Bold", Font.BOLD | Font.ITALIC, 16));
		lblMenu.setBounds(195, 23, 67, 14);
		contentPane.add(lblMenu);
		
		JButton btnSubmit = new JButton("Submit");
		btnSubmit.setFont(new Font("Adobe Caslon Pro Bold", Font.BOLD | Font.ITALIC, 16));
		btnSubmit.setBounds(173, 175, 89, 23);
		contentPane.add(btnSubmit);
		btnSubmit.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				try{
					
					
					Class.forName("com.mysql.jdbc.Driver");
				
					Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/q?useSSL=false","root","shan123");
					Statement stmt = con.createStatement();
					String x=textField.getText();
					String y=textField_1.getText();
					String sql = ("INSERT INTO orders (name,price) VALUES ('"+x+"','"+y+"')");
					stmt.executeUpdate(sql);
					con.close();
				}catch(Exception e1){
					System.out.println(e1);
				}
				
				
			}
		});
		
		textField = new JTextField();
		textField.setBounds(276, 87, 105, 38);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblYourOrders = new JLabel("Your Orders : ");
		lblYourOrders.setBounds(295, 53, 86, 20);
		contentPane.add(lblYourOrders);
		
		String[] noo = {"1","2"};
		JComboBox comboBox_1 = new JComboBox(noo);
		comboBox_1.setBounds(55, 127, 56, 20);
		contentPane.add(comboBox_1);
		
		textField_1 = new JTextField();
		textField_1.setBounds(276, 136, 86, 20);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		JLabel lblPrice = new JLabel("Price : ");
		lblPrice.setFont(new Font("Adobe Caslon Pro Bold", Font.BOLD | Font.ITALIC, 14));
		lblPrice.setBounds(220, 139, 42, 14);
		contentPane.add(lblPrice);
	}
}
