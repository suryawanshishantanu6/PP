import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Petrol.Admin;
import Petrol.CloseListner;
import Petrol.Emp;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;

public class Login extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login frame = new Login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Login() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblAkshay = new JLabel("Stationary managemnt sys");
		lblAkshay.setFont(new Font("Algerian", Font.BOLD | Font.ITALIC, 18));
		lblAkshay.setBounds(172, 11, 104, 22);
		contentPane.add(lblAkshay);
		
		JLabel lblUsername = new JLabel("Username : ");
		lblUsername.setFont(new Font("Adobe Caslon Pro Bold", Font.BOLD | Font.ITALIC, 16));
		lblUsername.setBounds(46, 81, 90, 14);
		contentPane.add(lblUsername);
		
		JLabel lblPassword = new JLabel("Password : ");
		lblPassword.setFont(new Font("Adobe Caslon Pro Bold", Font.BOLD | Font.ITALIC, 16));
		lblPassword.setBounds(46, 127, 90, 14);
		contentPane.add(lblPassword);
		
		textField = new JTextField();
		textField.setBounds(176, 78, 86, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JButton btnLogout = new JButton("Logout");
		btnLogout.addActionListener(new CloseListner() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnLogout.setFont(new Font("Adobe Caslon Pro Bold", Font.BOLD | Font.ITALIC, 14));
		btnLogout.setBounds(335, 42, 89, 23);
		contentPane.add(btnLogout);

		
		passwordField = new JPasswordField();
		passwordField.setBounds(176, 124, 86, 20);
		contentPane.add(passwordField);
		
		JButton btnSubmit = new JButton("Submit");
		btnSubmit.setFont(new Font("Adobe Caslon Pro Bold", Font.BOLD | Font.ITALIC, 16));
		btnSubmit.setBounds(173, 186, 89, 23);
		contentPane.add(btnSubmit);
		btnSubmit.addActionListener(new CloseListner() {
			public void actionPerformed(ActionEvent e) {
				String getvalue = textField.getText();
				String getpass = passwordField.getText();
				//String ser = "Supp";
				try{
					String x=textField.getText();
					String y=passwordField.getText();
					//String z=textField.getText();
					Class.forName("com.mysql.jdbc.Driver");
					Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/p?useSSL=false","root","shan123");
					Statement stmt = con.createStatement();
					
					String sql = ("INSERT INTO login (username,password) VALUES ('"+x+"','"+y+"')");
					stmt.executeUpdate(sql);
					con.close();
				}catch(Exception e1){
					System.out.println(e1);
				}
				
				
				if(new String("Chef").equals(getvalue) && new String("Chef123").equals(getpass)){
				Choice ad = new Choice();
				ad.setVisible(true);
				dispose();
				System.out.println(getvalue);
				System.out.println(getpass);
				}
				
				else if(new String("stat").equals(getvalue) && new String("stat123").equals(getpass)) 
				{
					Choice ad = new Choice();
					ad.setVisible(true);
					dispose();
					System.out.println(getvalue);
					System.out.println(getpass);
				}
				else if(new String("Customer").equals(getvalue) && new String("Customer123").equals(getpass)) 
				{
					Manager ad = new Manager();
					ad.setVisible(true);
					dispose();
					System.out.println(getvalue);
					System.out.println(getpass);
				}
				
				
				
				
				else {
					JOptionPane.showMessageDialog(null, "Enter Correct Credentilals...");
					
				}
			}
			
		});
	}
}
