

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CloseListner implements ActionListener {

	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		System.exit(0);

	}

}
